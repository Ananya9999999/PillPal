/**
 * database.js — uses sql.js (pure JS/WASM SQLite, no native compilation needed).
 * Provides a synchronous-style shim matching the better-sqlite3 API used in server.js.
 */
const initSqlJs = require('sql.js');
const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, 'pillpal.db');

let _rawDb = null;   // the raw sql.js Database instance
let db = null;       // the shim object exposed to server.js

// ─── Persist to disk ─────────────────────────────────────────────────────────
function persist() {
  if (!_rawDb) return;
  try {
    const data = _rawDb.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
  } catch (e) {
    console.error('DB save error:', e.message);
  }
}

// Auto-save every 3 s and on exit
setInterval(persist, 3000);
process.on('exit', persist);
process.on('SIGINT', () => { persist(); process.exit(0); });
process.on('SIGTERM', () => { persist(); process.exit(0); });

// ─── better-sqlite3 compatibility shim ───────────────────────────────────────
function createShim(rawDb) {
  return {
    // no-op — sql.js doesn't need pragma calls
    pragma: () => {},

    // Run one or more semicolon-separated statements (no params)
    exec(sql) {
      rawDb.run(sql);
      persist();
    },

    // Returns a statement-like object with .run(), .get(), .all()
    prepare(sql) {
      return {
        // INSERT / UPDATE / DELETE
        run(...args) {
          const params = flattenParams(args);
          rawDb.run(sql, params);
          // Grab last insert rowid synchronously
          const res = rawDb.exec('SELECT last_insert_rowid()');
          const lastInsertRowid = res[0]?.values[0][0] ?? 0;
          persist();
          return { lastInsertRowid, changes: 1 };
        },

        // SELECT — first row or undefined
        get(...args) {
          const params = flattenParams(args);
          const stmt = rawDb.prepare(sql);
          try {
            stmt.bind(params);
            return stmt.step() ? stmt.getAsObject() : undefined;
          } finally {
            stmt.free();
          }
        },

        // SELECT — all rows
        all(...args) {
          const params = flattenParams(args);
          const rows = [];
          const stmt = rawDb.prepare(sql);
          try {
            stmt.bind(params);
            while (stmt.step()) rows.push(stmt.getAsObject());
          } finally {
            stmt.free();
          }
          return rows;
        },
      };
    },
  };
}

// Normalise variadic vs array params
function flattenParams(args) {
  if (args.length === 0) return [];
  // Called as .run(...spreadArray) — already flat
  if (args.length === 1 && Array.isArray(args[0])) return args[0];
  return args;
}

// ─── Schema ───────────────────────────────────────────────────────────────────
const SCHEMA = `
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    avatar_color TEXT DEFAULT '#22d3ee',
    created_at DATETIME DEFAULT (datetime('now'))
  );
  CREATE TABLE IF NOT EXISTS medications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    dosage REAL NOT NULL,
    unit TEXT DEFAULT 'mg',
    color TEXT DEFAULT '#22d3ee',
    pill_type TEXT DEFAULT 'tablet',
    notes TEXT DEFAULT '',
    stock INTEGER DEFAULT 0,
    low_stock_alert INTEGER DEFAULT 10,
    active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT (datetime('now')),
    FOREIGN KEY (user_id) REFERENCES users(id)
  );
  CREATE TABLE IF NOT EXISTS schedules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    medication_id INTEGER NOT NULL,
    time TEXT NOT NULL,
    days_of_week TEXT DEFAULT '1,2,3,4,5,6,7',
    compartment INTEGER DEFAULT 1,
    dose_count INTEGER DEFAULT 1,
    active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT (datetime('now')),
    FOREIGN KEY (medication_id) REFERENCES medications(id)
  );
  CREATE TABLE IF NOT EXISTS dispense_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    medication_id INTEGER NOT NULL,
    schedule_id INTEGER,
    status TEXT DEFAULT 'taken',
    notes TEXT DEFAULT '',
    dispensed_at DATETIME DEFAULT (datetime('now')),
    FOREIGN KEY (medication_id) REFERENCES medications(id)
  );
  CREATE TABLE IF NOT EXISTS device_status (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    device_id TEXT DEFAULT 'PILLPAL-001',
    connected INTEGER DEFAULT 0,
    battery_level INTEGER DEFAULT 100,
    compartment_status TEXT DEFAULT '{}',
    last_seen DATETIME DEFAULT (datetime('now')),
    FOREIGN KEY (user_id) REFERENCES users(id)
  );
`;

// ─── Async init (called once in server.js before app.listen) ─────────────────
async function initDB() {
  const SQL = await initSqlJs();

  if (fs.existsSync(DB_PATH)) {
    const buf = fs.readFileSync(DB_PATH);
    _rawDb = new SQL.Database(buf);
    console.log('💾 Loaded existing database from disk');
  } else {
    _rawDb = new SQL.Database();
    console.log('🆕 Created new database');
  }

  db = createShim(_rawDb);
  db.exec(SCHEMA);
  console.log('✅ Database initialised successfully');
}

module.exports = { get db() { return db; }, initDB };
